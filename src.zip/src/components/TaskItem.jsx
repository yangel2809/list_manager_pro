import React, { useState } from 'react';
import { useTasks } from '../context/TaskContext';

const TaskItem = ({ task }) => {
  const { deleteTask, toggleTask, updateTask } = useTasks();
  
  // Estado local para controlar si estamos editando esta tarea
  const [isEditing, setIsEditing] = useState(false);
  // Estado local para el texto que se está escribiendo mientras editamos
    const [editValues, setEditValues] = useState({
      text: task.text,
      category: task.category,
      priority: task.priority,
      dueDate: task.dueDate || ''
    });

    const [showConfirm, setShowConfirm] = useState(false);


    const handleDelete = () => {
    deleteTask(task.id);
    setShowConfirm(false);
    };
  const handleSave = () => {
    if (editValues.text.trim() === "") {
      alert("El texto es un campo obligatorio");
      return;
    }
    updateTask(task.id, editValues);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditValues({
        text: task.text,
        category: task.category,
        priority: task.priority
    });
    setIsEditing(false);
  };

  const isOverdue = () => {
  if (!task.dueDate || task.completed) return false;

  const today = new Date();
  today.setHours(0, 0, 0, 0); // Normalizamos a las 00:00 para comparar solo días
  
  const due = new Date(task.dueDate);
  due.setHours(0, 0, 0, 0);

  return due < today;
};

  // RENDERIZADO CONDICIONAL
 return (

    
    <li style={{ marginBottom: '10px', listStyle: 'none' }}>
      {isEditing ? (

        
        <div className="edit-mode">
          {/* Editar Texto */}
          <input 
            type="text" 
            value={editValues.text} 
            onChange={(e) => setEditValues({...editValues, text: e.target.value})}
          />

          {/* Editar Categoría */}
          <select 
            value={editValues.category} 
            onChange={(e) => setEditValues({...editValues, category: e.target.value})}
          >
            <option value="Personal">Personal</option>
            <option value="Trabajo">Trabajo</option>
            <option value="Urgente">Urgente</option>
          </select>

          {/* Editar Prioridad */}
          <select 
            value={editValues.priority} 
            onChange={(e) => setEditValues({...editValues, priority: e.target.value})}
          >
            <option value="Baja">Baja</option>
            <option value="Media">Media</option>
            <option value="Alta">Alta</option>
          </select>

          <button onClick={handleSave}>✅</button>
          <button onClick={() => setIsEditing(false)}>❌</button>
        </div>
      ) : (
        <div className="view-mode">
          <input 
            type="checkbox" 
            checked={task.completed} 
            onChange={() => toggleTask(task.id)} 
          />
          <span style={{ 
            textDecoration: task.completed ? 'line-through' : 'none',
            color: isOverdue() ? 'red' : 'inherit'
          }}>
            <strong>[{task.priority}]</strong> {task.text} 
            <small> (#{task.category})</small>
            {task.dueDate && <small> — Vence: {task.dueDate}</small>}
            {isOverdue() && <strong style={{ marginLeft: '6px' }}>⚠️ ¡VENCIDA!</strong>}
          </span>
          <div className="actions">
            {showConfirm ? (
              <div className="confirm-box" style={{ background: '#ffebee', padding: '5px', borderRadius: '4px' }}>
                <small>¿Borrar?</small>
                <button onClick={handleDelete} style={{ color: 'red', marginLeft: '5px' }}>Sí</button>
                <button onClick={() => setShowConfirm(false)} style={{ marginLeft: '5px' }}>No</button>
              </div>
            ) : (
              <>
                <button onClick={() => setIsEditing(true)}>📝</button>
                <button onClick={() => setShowConfirm(true)}>🗑️</button>
              </>
            )}
          </div>
        </div>
      )}
    </li>
  );
};

export default TaskItem;