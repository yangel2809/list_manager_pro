import React, { useState } from 'react';
import { useTasks } from '../context/TaskContext';

const TaskInput = () => {
  const [text, setText] = useState('');
  const [category, setCategory] = useState('Personal'); // Valor por defecto
  const [priority, setPriority] = useState('Media');    // Valor por defecto
  const [dueDate, setDueDate] = useState('');
  const { addTask } = useTasks();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!text.trim()) return alert("Escribe una tarea");
    
    // Ahora enviamos los datos reales elegidos por el usuario
    addTask(text, category, priority, dueDate);
    
    // Resetear el formulario
    setText('');
    setDueDate('');
    setCategory('Personal');
    setPriority('Media');
  };

  return (
    <form onSubmit={handleSubmit} style={{ border: '1px solid #ccc', padding: '10px', marginBottom: '20px' }}>
      <input 
        type="date" 
        value={dueDate} 
        onChange={(e) => setDueDate(e.target.value)} 
        />
      <input 
        type="text" 
        value={text} 
        onChange={(e) => setText(e.target.value)} 
        placeholder="¿Qué hay que hacer?"
      />

      {/* Selector de Categoría */}
      <select value={category} onChange={(e) => setCategory(e.target.value)}>
        <option value="Personal">👤 Personal</option>
        <option value="Trabajo">💼 Trabajo</option>
        <option value="Gym">🏋️ Gym</option>
        <option value="Medicina">🏥 Medicina</option>
        <option value="hogar">🏠 Hogar</option>
      </select>

      {/* Selector de Prioridad */}
      <select value={priority} onChange={(e) => setPriority(e.target.value)}>
        <option value="Baja">🟢 Baja</option>
        <option value="Media">🟡 Media</option>
        <option value="Alta">🔴 Alta</option>
      </select>

      <button type="submit">Agregar</button>
    </form>
  );
};

export default TaskInput;