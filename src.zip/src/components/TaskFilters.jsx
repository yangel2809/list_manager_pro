import React from 'react';

const TaskFilters = ({ filterStatus, setFilterStatus, searchTerm, setSearchTerm, filterPriority, setFilterPriority }) => {
  return (
    <div style={{ marginBottom: '20px', padding: '10px', background: '#f4f4f4' }}>
      {/* 1. Búsqueda por texto */}
      <input 
        type="text" 
        placeholder="Buscar tarea..." 
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      {/* 2. Filtro por Estado */}
      <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
        <option value="all">Todas</option>
        <option value="active">Pendientes</option>
        <option value="completed">Completadas</option>
      </select>

      {/* 3. Filtro por Prioridad */}
      <select value={filterPriority} onChange={(e) => setFilterPriority(e.target.value)}>
        <option value="all">Todas las prioridades</option>
        <option value="Alta">🔴 Alta</option>
        <option value="Media">🟡 Media</option>
        <option value="Baja">🟢 Baja</option>
      </select>
    </div>
  );
};

export default TaskFilters;