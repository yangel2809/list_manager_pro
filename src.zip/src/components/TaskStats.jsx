import React from 'react';

const TaskStats = ({ tasks }) => {
  // 1. Cálculos lógicos
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const pendingTasks = totalTasks - completedTasks;
  
  // Cálculo de porcentaje con protección contra división por cero (NaN)
  const progressPercentage = totalTasks > 0 
    ? Math.round((completedTasks / totalTasks) * 100) : totalTasks === 0
    ? 0 : 0;

  // Filtrado por prioridades para métricas específicas
  const highPriorityPending = tasks.filter(t => t.priority === 'Alta' && !t.completed).length;

  return (
    <div style={{ 
      display: 'flex', 
      gap: '20px', 
      padding: '15px', 
      background: '#eee', 
      borderRadius: '8px',
      marginBottom: '20px' 
    }}>
      <div>
        <strong>Progreso:</strong> {progressPercentage}%
        <div style={{ width: '100px', background: '#ccc', height: '10px' }}>
          <div style={{ 
            width: `${progressPercentage}%`, 
            background: 'green', 
            height: '100%',
            transition: 'width 0.3s ease' 
          }}></div>
        </div>
      </div>

      <div>
        <strong>Total:</strong> {totalTasks}
      </div>

      <div>
        <strong>Pendientes:</strong> {pendingTasks}
      </div>

      {highPriorityPending > 0 && (
        <div style={{ color: 'red' }}>
          <strong>⚠️ Urgentes:</strong> {highPriorityPending}
        </div>
      )}
    </div>
  );
};

export default TaskStats;