import React from 'react';
import { useTasks } from '../context/TaskContext';
import TaskItem from './TaskItem';

const TaskList = ({ tasks }) => {

  return (
    <ul>
      {tasks.length > 0 ? (
        tasks.map(task => <TaskItem key={task.id} task={task} />)
      ) : (
        <p>No hay tareas que coincidan con los filtros.</p>
      )}
    </ul>
  );
};

export default TaskList;