import React, { useState } from 'react';
import { useTasks } from './context/TaskContext';
import TaskInput from './components/TaskInput';
import TaskList from './components/TaskList';
import TaskFilters from './components/TaskFilters';
import TaskStats from './components/TaskStats';

export default function App() {
  const { tasks } = useTasks();

  // Estados locales para los filtros (No necesitan estar en el Contexto)
  const [filterStatus, setFilterStatus] = useState('all'); // all, active, completed
  const [filterPriority, setFilterPriority] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // --- LÓGICA DE FILTRADO (Estado Derivado) ---
  const filteredTasks = tasks.filter(task => {
    // 1. Filtrar por texto
    const matchesSearch = task.text.toLowerCase().includes(searchTerm.toLowerCase());
    
    // 2. Filtrar por estado (Pendiente/Completada)
    const matchesStatus = 
      filterStatus === 'all' ? true : 
      filterStatus === 'completed' ? task.completed : !task.completed;
    
    // 3. Filtrar por prioridad
    const matchesPriority = 
      filterPriority === 'all' ? true : task.priority === filterPriority;

    return matchesSearch && matchesStatus && matchesPriority;
  });

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      <h1>Gestor de Tareas Pro</h1>

      <TaskStats tasks={tasks} />

      <TaskInput />
      
      <TaskFilters 
        filterStatus={filterStatus} setFilterStatus={setFilterStatus}
        searchTerm={searchTerm} setSearchTerm={setSearchTerm}
        filterPriority={filterPriority} setFilterPriority={setFilterPriority}
      />

      <TaskList tasks={filteredTasks} />
    </div>
  );
}